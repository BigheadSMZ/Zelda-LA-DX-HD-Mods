		Female Player Dialog for Link's Awakening DX HD
		by Dittron

	1.) Overview
--------------------------------------------------------------------------------------------------------
		This mod tweaks the game dialog to be more suitable for a female protagonist. It pairs well with 
		player replacement mods. There are two version of the mod: the "Lite" version that tries to be 
		vanilla friendly and only change what's necessary ("boy" to "girl" or "lad" to "lass"), and the 
		"Extended" version that goes a step further and alters certain lines that might not fit a 
		female protagonist. A section down below will highlight some of the changes in the Extended 
		version and explain why they were made.
	
		Note: There is a Spanish version for the Lite version only. It was made through a combination of 
		machine translation and my surface level knowledge of Spanish. Expect there to be mistakes 
		and/or missing lines. Please let me know about any mistakes so that I can correct them. I'm open 
		to supporting more languages but I need help to implement them properly.


	2.) Installation 
--------------------------------------------------------------------------------------------------------
		Copy the "Mods" folder from inside either the "Lite" or "Extended" folder into your LADXHD game
		directory.


	3.) Dialog Changes
--------------------------------------------------------------------------------------------------------
		The Lite version is what you would expect from a mod like this. Any reference to the 
		protagonist's gender is changed to female. It's vanilla friendly and only changes what's 
		necessary.
		
		Inserting a female protagonist into the story in a believable way requires more than just 
		changing pronouns. That's where the Extended version comes in. The goals of this version are to 
		rewrite certain lines to reduce the amount of romantic or suggestive implications involving the 
		protagonist and also tweak how some characters interact with you. Many of the changes were made 
		by referencing other translations of the script to try to keep it as "official" as possible. 
		However, some creative liberties are taken in a few instances. Only English lines are changed in 
		the Extended version.

		I'm going to run through a few examples from the Extended version just to highlight some of the 
		changes and why they were made:
		
		Example 1 - Marin during the beach scene

			Original: 	"I want to know everything about you...Err...Uhh, Ha ha ha ha!"
		
			Modded:		"Someday I'd like to visit the place you're from. Oh, sometimes I say such 
						silly things... Heh, heh..."

		This line is pulled from the Spanish translation, which is itself a more faithful version of the 
		Japanese line. Apparently this is supposed to be a love confession in Japanese but it doesn't 
		carry the same meaning in English so let's go with it here.

		Example 2 - When speaking to the village boys with Marin following you

			Original:	"Hey... Where're you two going together? Hunh? Uh, I didn't mean anything...
						I'm just a kid!"
						
			Modded:		"There are some things around here that you can only do with a pal!
						Don't ask me what that means, I'm just a kid!"

		This is a tough one. The kids are clearly teasing you about being on a "date." It's the same in 
		every version of the script that I could check so there's no official alternative here. 
		Considering the goals of this version, leaving it doesn't feel right so we'll have to come up 
		with something original. 
		
		The boys often give the player hints then follow it up with "I'm just a kid." Since there are 
		missable events during this section of the game, the new line hints for you to explore with 
		Marin following you. I'm not a fan of completely changing the line but at least it's more 
		useful now.

		Example 3 - *That* interaction with Martha the mermaid

			Original:	"Kyaa! Pervert! Perveeert!!!"
		
			Modded:		"No scales before I have my bra back!"

		So... in the Redux (uncensored) version of the script, the mermaid is missing her bra instead of
		her necklace. This particular line happens if you dive under the water next to her before 
		finding her bra. She (understandably) screams at Link, but I don't feel like she'd have the 
		same reaction with a female character. This replacement line is taken from the Switch version 
		except "necklace" is replaced with "bra" of course. It's an official line modified to refer to 
		the Redux item so it works.


	4.) Final Thoughts
--------------------------------------------------------------------------------------------------------
		One of my favorite types of mods are ones that allow you to play as a new character. It's a 
		simple way to make a familiar game feel fresh again without losing what made the game special 
		to begin with. It gets more complicated when inserting a female protagonist into a story like 
		Link's Awakening since the game's script was written around Link. I wanted to make playing as a 
		new character believable, as if it was originally written with a female protagonist in mind. At 
		the same time I wanted to avoid overstepping and the mod feeling too much like fanfiction. Some 
		players might even be perfectly fine with the original script and I wouldn't want to force 
		unnecessary changes onto them. Overall I think that I was able to find a good balance but I am 
		open to suggestions for improvement. I'd love to get some feedback as this has been a solo 
		project up to this point. 

		Anyway, thanks for reading this! I've put a lot of time and thought into this mod so I hope 
		that it can enhance your experience when playing this classic adventure.


	5.) Sources
--------------------------------------------------------------------------------------------------------
		Álcam & IPeluchito - Spanish translation for LADXHD
		
		Elizabeth Bushouse - Zelda: Link’s Awakening Script Comparison
							 (https://lizbushouse.com/zelda-links-awakening-script-comparison/)